import dropbox

dropbox_access_token= "UErlsp4uNE4AAAAAAAAAAfUN5onvPKJNlyS8ulmwcQa8LEpoRm3rUZAt4LOJSk5N"    #Enter your own access token
dropbox_path= "/pythonuploader16073/sample.jpg"
computer_path='sample.jpg'

client = dropbox.Dropbox(dropbox_access_token)
print("[SUCCESS] dropbox account linked")

client.files_upload(open(computer_path, "rb").read(), dropbox_path)
print("[UPLOADED] {}".format(computer_path))