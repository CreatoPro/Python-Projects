import json
import requests
headers = {"Authorization": "Bearer ya29.a0ARrdaM9AmBRm7xoDpKf6LOpl90CRd-1XOfYk7eTJEolf-lSireMIFlk4JIkY5tpI35TcNmLo3UJGgmI5cUbmlacHo8HgXqXCahGYZ-Hnjg0kFj_qs-VsTbt-wjat0wkGdEHn-Pguz8jZaJU1Y_j5kvJoKVzk"}
para = {
    "name": "sample.jpg",
}
files = {
    'data': ('metadata', json.dumps(para), 'application/json; charset=UTF-8'),
    'file': open("./sample.jpg", "rb")
}
r = requests.post(
    "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart",
    headers=headers,
    files=files
)
print(r.text)